const heart = document.getElementById('heart');
const message = document.getElementById('message');
const container = document.querySelector('.container');

heart.addEventListener('click', () => {
  // Hide the heart and click message
  container.style.display = 'none';

  // Show the hidden love message
  message.classList.remove('hidden');
});